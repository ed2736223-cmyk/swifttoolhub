import type { Metadata } from "next";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ScrollProgress from "@/components/ScrollProgress";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description: "How SwiftToolHub collects, uses, and protects your information.",
};

export default function PrivacyPolicyPage() {
  return (
    <>
      <ScrollProgress />
      <Navbar />
      <main className="mx-auto max-w-3xl px-4 pb-24 pt-32">
        <span className="inline-flex items-center rounded-full bg-brand-soft px-4 py-1.5 text-xs font-semibold text-brand">
          Legal
        </span>
        <h1 className="mt-4 text-3xl font-bold sm:text-4xl">Privacy Policy</h1>
        <p className="mt-2 text-sm text-heading/50">Last updated: July 2026</p>

        <div className="mt-8 space-y-8 text-sm leading-relaxed text-heading/70">
          <section>
            <h2 className="text-lg font-semibold text-heading">1. Overview</h2>
            <p className="mt-2">
              SwiftToolHub (&quot;we&quot;, &quot;us&quot;) operates swifttoolhub.com. This
              page explains what information is collected when you use the
              site and how it&apos;s handled. Using the site means you agree to
              the practices described here.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-heading">2. Information Processed By Tools</h2>
            <p className="mt-2">
              Most tools on this site — including text, image, and file-based
              tools — process your input directly in your browser using
              JavaScript. That data is not uploaded to our servers unless a
              specific tool explicitly states otherwise on its page.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-heading">3. Cookies And Similar Technologies</h2>
            <p className="mt-2">
              We use a minimal set of cookies for basic site functionality.
              Third-party services we use — including Google AdSense and
              analytics providers — may set their own cookies to serve
              relevant ads and measure site performance. You can control
              cookies through your browser settings at any time.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-heading">4. Advertising</h2>
            <p className="mt-2">
              This site displays ads served by Google AdSense. Google and its
              partners may use cookies to serve ads based on your prior
              visits to this or other websites. You can opt out of
              personalized advertising by visiting{" "}
              <a href="https://adssettings.google.com" className="text-brand underline" target="_blank" rel="noopener noreferrer">
                Google Ads Settings
              </a>
              .
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-heading">5. Analytics</h2>
            <p className="mt-2">
              We may use analytics tools to understand aggregate usage
              patterns — such as which pages are visited and for how long —
              to improve the site. This data is not used to identify
              individual visitors.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-heading">6. Data We Don&apos;t Collect</h2>
            <p className="mt-2">
              We don&apos;t require account creation, and we don&apos;t knowingly
              collect names, addresses, or payment details through the
              tools themselves. Any information you send us directly, such
              as through the contact form or email, is used only to respond
              to you.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-heading">7. Children&apos;s Privacy</h2>
            <p className="mt-2">
              This site is not directed at children under 13, and we do not
              knowingly collect personal information from children.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-heading">8. Changes To This Policy</h2>
            <p className="mt-2">
              We may update this policy from time to time. Continued use of
              the site after changes are posted means you accept the
              updated policy.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-heading">9. Contact</h2>
            <p className="mt-2">
              Questions about this policy can be sent to{" "}
              <a href="mailto:hello@swifttoolhub.com" className="text-brand underline">
                hello@swifttoolhub.com
              </a>
              .
            </p>
          </section>
        </div>
      </main>
      <Footer />
    </>
  );
}
