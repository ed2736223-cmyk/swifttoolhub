import type { Metadata } from "next";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import ScrollProgress from "@/components/ScrollProgress";

export const metadata: Metadata = {
  title: "Terms of Service",
  description: "The terms that govern your use of SwiftToolHub.",
};

export default function TermsPage() {
  return (
    <>
      <ScrollProgress />
      <Navbar />
      <main className="mx-auto max-w-3xl px-4 pb-24 pt-32">
        <span className="inline-flex items-center rounded-full bg-brand-soft px-4 py-1.5 text-xs font-semibold text-brand">
          Legal
        </span>
        <h1 className="mt-4 text-3xl font-bold sm:text-4xl">Terms of Service</h1>
        <p className="mt-2 text-sm text-heading/50">Last updated: July 2026</p>

        <div className="mt-8 space-y-8 text-sm leading-relaxed text-heading/70">
          <section>
            <h2 className="text-lg font-semibold text-heading">1. Acceptance Of Terms</h2>
            <p className="mt-2">
              By accessing or using swifttoolhub.com, you agree to be bound
              by these terms. If you don&apos;t agree, please don&apos;t use the
              site.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-heading">2. Use Of Tools</h2>
            <p className="mt-2">
              Tools on this site are provided &quot;as is&quot; for general
              informational and productivity purposes. You&apos;re responsible
              for verifying results before relying on them for anything
              important — including generated files, passwords, or
              converted content.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-heading">3. Acceptable Use</h2>
            <p className="mt-2">
              You agree not to misuse the site — including attempting to
              disrupt service, scrape content at scale, or use any tool for
              unlawful purposes.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-heading">4. Intellectual Property</h2>
            <p className="mt-2">
              The SwiftToolHub name, logo, design, and original site content
              belong to us. Content you generate using the tools (converted
              files, generated text, etc.) belongs to you.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-heading">5. Third-Party Advertising</h2>
            <p className="mt-2">
              This site displays third-party advertisements, including
              through Google AdSense. We aren&apos;t responsible for the
              content of ads served by third parties.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-heading">6. Disclaimer Of Warranties</h2>
            <p className="mt-2">
              We work to keep every tool accurate and available, but we make
              no guarantee the site will be error-free or uninterrupted.
              Tools are provided without warranties of any kind.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-heading">7. Limitation Of Liability</h2>
            <p className="mt-2">
              We aren&apos;t liable for any indirect, incidental, or
              consequential damages arising from your use of the site or
              its tools.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-heading">8. Changes To These Terms</h2>
            <p className="mt-2">
              We may revise these terms periodically. Continued use of the
              site after updates constitutes acceptance of the revised
              terms.
            </p>
          </section>

          <section>
            <h2 className="text-lg font-semibold text-heading">9. Contact</h2>
            <p className="mt-2">
              Questions about these terms can be sent to{" "}
              <a href="mailto:hello@swifttoolhub.com" className="text-brand underline">
                hello@swifttoolhub.com
              </a>
              .
            </p>
          </section>
        </div>
      </main>
      <Footer />
    </>
  );
}
