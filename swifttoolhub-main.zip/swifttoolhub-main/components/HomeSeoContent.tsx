import Link from "next/link";
import Reveal from "./Reveal";

const categories = [
  {
    name: "Convert",
    desc: "image to PDF, unit conversion, CSV to JSON, timestamp conversion, text case conversion, and more",
  },
  {
    name: "Generate",
    desc: "QR codes, strong passwords, random numbers, favicons, meta tags, and more",
  },
  {
    name: "Check",
    desc: "word counters, percentage and BMI calculators, age calculators, text diff checkers, and more",
  },
  {
    name: "Develop",
    desc: "JSON formatting and validation, Base64 encoding and decoding, color conversion, URL encoding, SHA-256 hash generation, and more",
  },
  {
    name: "More",
    desc: "explore additional tools for everyday tasks, calculations, conversions, formatting, and productivity",
  },
];

const signupSteps = [
  "Visit SwiftToolHub and browse or search for the tool you need.",
  "Select a tool to open its dedicated page.",
  "Enter or upload your data as required by the tool.",
  "Click the relevant action button to process your input.",
  "View or download your result instantly.",
  "Create a free account only if needed for extras like saved history or higher usage limits.",
];

export default function HomeSeoContent() {
  return (
    <section className="bg-white px-4 py-24">
      <div className="mx-auto max-w-3xl space-y-14 text-sm leading-relaxed text-heading/70">
        <Reveal>
          <h2 className="text-2xl font-bold text-heading sm:text-3xl">What is SwiftToolHub?</h2>
          <p className="mt-4">
            SwiftToolHub is a free online toolkit offering 25+ (and growing) browser-based utilities
            for everyday work. It brings converters, generators, checkers, and calculators — like a
            JSON formatter, QR code generator, password generator, and unit converter — into one clean
            workspace.
          </p>
          <p className="mt-4">
            We work as a team to build a platform that requires no sign-up to use the core tools, with
            most processing happening directly in your browser for speed and privacy. Paid tools are
            available individually for people who want extra features on top of the free library.
          </p>
        </Reveal>

        <Reveal delay={1}>
          <h2 className="text-2xl font-bold text-heading sm:text-3xl">
            Use Free Online Converters, Generators and Checkers in One Place at SwiftToolHub
          </h2>
          <p className="mt-4">
            Instead of searching for a different website every time you need to convert an image to
            PDF, generate a QR code, or check your website&apos;s meta tags, SwiftToolHub keeps
            everything under one roof. The tool library covers these categories:
          </p>
          <ul className="mt-4 space-y-2">
            {categories.map((c) => (
              <li key={c.name}>
                <span className="font-semibold text-heading">{c.name}</span> ({c.desc})
              </li>
            ))}
          </ul>
        </Reveal>

        <Reveal delay={2}>
          <h2 className="text-2xl font-bold text-heading sm:text-3xl">
            How to Sign Up on SwiftToolHub for Tools?
          </h2>
          <p className="mt-4">
            One of the most common frustrations with free online tools is being asked to create an
            account before you can even see the results. On SwiftToolHub, you can instantly do the
            following:
          </p>
          <ol className="mt-4 list-decimal space-y-2 pl-5">
            {signupSteps.map((s) => (
              <li key={s}>{s}</li>
            ))}
          </ol>
        </Reveal>

        <Reveal delay={3}>
          <h2 className="text-2xl font-bold text-heading sm:text-3xl">
            We Never Compromise on Speed At SwiftToolHub
          </h2>
          <p className="mt-4">
            Speed matters when a task should only take a few seconds. Most tools on SwiftToolHub run
            directly in the browser rather than sending files to a distant server and waiting for a
            response, which means results appear almost instantly — no queue, no spinner, no page
            reload between tools. This browser-based approach also means many tools work offline-
            friendly and consistently.
          </p>
        </Reveal>

        <Reveal delay={4}>
          <h2 className="text-2xl font-bold text-heading sm:text-3xl">
            SwiftToolHub Built With Privacy in Mind
          </h2>
          <p className="mt-4">
            Free tools often come with a hidden cost, such as unclear handling of the files and text
            you upload. SwiftToolHub processes data locally in the browser wherever technically
            possible, so sensitive text, code, or images don&apos;t need to be sent anywhere to get a
            result. When server-side processing is unavoidable, files are removed shortly afterwards
            rather than stored indefinitely.
          </p>
        </Reveal>

        <Reveal delay={1}>
          <h2 className="text-2xl font-bold text-heading sm:text-3xl">
            A Growing Library That is Shaped by Real Requests
          </h2>
          <p className="mt-4">
            New tools are added on a regular basis, and many of them come directly from user requests
            submitted through the contact page. The goal isn&apos;t to build every tool imaginable, but
            to build the ones people actually reach for — free, fast, reliable, and ready the moment
            you need them.{" "}
            <Link href="/contact" className="font-semibold text-brand">
              Contact us
            </Link>{" "}
            if you want to see a specific tool on SwiftToolHub or if you have an idea for a new tool
            that would be useful to the community.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
